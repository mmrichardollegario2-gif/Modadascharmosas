export type Product = {
  id: number;
  name: string;
  slug: string;
  code: string;
  description: string;
  price: number;
  comparePrice?: number;
  categorySlug: string;
  categoryName: string;
  stock: number;
  featured?: boolean;
  isNew?: boolean;
  onSale?: boolean;
  clicks: number;
  sizes: string[];
  colors: string[];
  images: string[];
};

export const categories = [
  { name: "Vestidos", slug: "vestidos" },
  { name: "Blusas", slug: "blusas" },
  { name: "Calças", slug: "calcas" },
  { name: "Saias", slug: "saias" },
  { name: "Acessórios", slug: "acessorios" },
];

function img(seed: string, w = 800, h = 1000) {
  return `https://picsum.photos/seed/${seed}/${w}/${h}`;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Vestido Midi Elegance",
    slug: "vestido-midi-elegance",
    code: "#6869",
    description:
      "Vestido midi em tecido fluido, caimento leve e decote em V. Peça versátil para do dia à noite.",
    price: 189.9,
    comparePrice: 229.9,
    categorySlug: "vestidos",
    categoryName: "Vestidos",
    stock: 8,
    featured: true,
    onSale: true,
    clicks: 132,
    sizes: ["P", "M", "G"],
    colors: ["Rosa", "Preto"],
    images: [img("vestido-midi-1"), img("vestido-midi-2")],
  },
  {
    id: 2,
    name: "Vestido Charme Longo",
    slug: "vestido-charme-longo",
    code: "#6870",
    description: "Vestido longo com fenda lateral, alças finas e tecido com leve brilho.",
    price: 259.9,
    categorySlug: "vestidos",
    categoryName: "Vestidos",
    stock: 5,
    isNew: true,
    clicks: 98,
    sizes: ["P", "M", "G", "GG"],
    colors: ["Preto", "Vermelho"],
    images: [img("vestido-longo-1"), img("vestido-longo-2")],
  },
  {
    id: 3,
    name: "Vestido Amora Curto",
    slug: "vestido-amora-curto",
    code: "#6871",
    description: "Vestido curto acinturado, ideal para eventos e encontros especiais.",
    price: 169.9,
    comparePrice: 199.9,
    categorySlug: "vestidos",
    categoryName: "Vestidos",
    stock: 0,
    onSale: true,
    clicks: 71,
    sizes: ["PP", "P", "M"],
    colors: ["Rosa"],
    images: [img("vestido-curto-1")],
  },
  {
    id: 4,
    name: "Blusa Charmosa Cropped",
    slug: "blusa-charmosa-cropped",
    code: "#6872",
    description: "Blusa cropped em tricô, textura canelada e caimento ajustado.",
    price: 89.9,
    categorySlug: "blusas",
    categoryName: "Blusas",
    stock: 15,
    featured: true,
    isNew: true,
    clicks: 154,
    sizes: ["P", "M", "G"],
    colors: ["Branco", "Preto", "Rosa"],
    images: [img("blusa-1"), img("blusa-2")],
  },
  {
    id: 5,
    name: "Blusa Seda Essence",
    slug: "blusa-seda-essence",
    code: "#6873",
    description: "Blusa de manga longa com toque acetinado, elegante para o trabalho.",
    price: 119.9,
    categorySlug: "blusas",
    categoryName: "Blusas",
    stock: 10,
    clicks: 62,
    sizes: ["P", "M", "G", "GG"],
    colors: ["Branco", "Azul"],
    images: [img("blusa-3")],
  },
  {
    id: 6,
    name: "Blusa Laço Delicada",
    slug: "blusa-laco-delicada",
    code: "#6874",
    description: "Blusa com amarração frontal em laço e mangas bufantes.",
    price: 99.9,
    comparePrice: 129.9,
    categorySlug: "blusas",
    categoryName: "Blusas",
    stock: 12,
    onSale: true,
    clicks: 87,
    sizes: ["PP", "P", "M"],
    colors: ["Rosa", "Branco"],
    images: [img("blusa-4")],
  },
  {
    id: 7,
    name: "Calça Alfaiataria Charme",
    slug: "calca-alfaiataria-charme",
    code: "#6875",
    description: "Calça de alfaiataria em cintura alta, corte reto e caimento impecável.",
    price: 149.9,
    categorySlug: "calcas",
    categoryName: "Calças",
    stock: 9,
    featured: true,
    clicks: 76,
    sizes: ["36", "38", "40", "42"],
    colors: ["Preto"],
    images: [img("calca-1"), img("calca-2")],
  },
  {
    id: 8,
    name: "Calça Wide Leg Flow",
    slug: "calca-wide-leg-flow",
    code: "#6876",
    description: "Calça pantalona fluida, cintura alta com amarração.",
    price: 159.9,
    categorySlug: "calcas",
    categoryName: "Calças",
    stock: 6,
    isNew: true,
    clicks: 54,
    sizes: ["36", "38", "40"],
    colors: ["Verde", "Preto"],
    images: [img("calca-3")],
  },
  {
    id: 9,
    name: "Saia Midi Plissada",
    slug: "saia-midi-plissada",
    code: "#6877",
    description: "Saia midi plissada, tecido leve com caimento fluido.",
    price: 129.9,
    categorySlug: "saias",
    categoryName: "Saias",
    stock: 7,
    clicks: 65,
    sizes: ["P", "M", "G"],
    colors: ["Rosa", "Preto"],
    images: [img("saia-1")],
  },
  {
    id: 10,
    name: "Saia Charme Jeans",
    slug: "saia-charme-jeans",
    code: "#6878",
    description: "Saia jeans com botões frontais e barra desfiada.",
    price: 109.9,
    comparePrice: 139.9,
    categorySlug: "saias",
    categoryName: "Saias",
    stock: 11,
    onSale: true,
    clicks: 90,
    sizes: ["36", "38", "40", "42"],
    colors: ["Azul"],
    images: [img("saia-2")],
  },
  {
    id: 11,
    name: "Bolsa Charmosa Tote",
    slug: "bolsa-charmosa-tote",
    code: "#6879",
    description: "Bolsa tote estruturada em couro sintético premium.",
    price: 139.9,
    categorySlug: "acessorios",
    categoryName: "Acessórios",
    stock: 14,
    featured: true,
    clicks: 112,
    sizes: ["Único"],
    colors: ["Preto", "Rosa"],
    images: [img("bolsa-1")],
  },
  {
    id: 12,
    name: "Brinco Charme Dourado",
    slug: "brinco-charme-dourado",
    code: "#6880",
    description: "Brinco banhado a ouro com design delicado e atemporal.",
    price: 49.9,
    categorySlug: "acessorios",
    categoryName: "Acessórios",
    stock: 20,
    isNew: true,
    clicks: 47,
    sizes: ["Único"],
    colors: ["Amarelo"],
    images: [img("brinco-1")],
  },
];

export function getProductBySlug(slug: string) {
  return products.find((p) => p.slug === slug);
}

export function getRelated(product: Product, limit = 4) {
  return products
    .filter((p) => p.categorySlug === product.categorySlug && p.id !== product.id)
    .slice(0, limit);
}
