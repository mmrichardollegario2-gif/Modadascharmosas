export const storeConfig = {
  name: "Moda das Charmosas",
  whatsappNumber: "5500000000000", // TODO: administrador troca em /admin/configuracoes
  instagramHandle: "@modadascharmosas",
  instagramUrl: "https://instagram.com/modadascharmosas",
};

export function formatPrice(value: number) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function buildWhatsappMessage({
  productName,
  code,
  price,
  size,
  color,
  url,
}: {
  productName: string;
  code: string;
  price: number;
  size?: string;
  color?: string;
  url: string;
}) {
  const lines = [
    "Olá! Tenho interesse neste produto:",
    "",
    `👗 ${productName}`,
    `🏷️ Código: ${code}`,
    `💰 Preço: ${formatPrice(price)}`,
  ];
  if (size) lines.push(`📏 Tamanho: ${size}`);
  if (color) lines.push(`🎨 Cor: ${color}`);
  lines.push("", `Vi esse produto no site da ${storeConfig.name}.`, url);
  return lines.join("\n");
}

export function buildInstagramMessage({
  productName,
  code,
  price,
  size,
  color,
}: {
  productName: string;
  code: string;
  price: number;
  size?: string;
  color?: string;
}) {
  const lines = [
    "Olá! Tenho interesse no produto:",
    "",
    productName,
    `Código: ${code}`,
    `Preço: ${formatPrice(price)}`,
  ];
  if (size) lines.push(`Tamanho: ${size}`);
  if (color) lines.push(`Cor: ${color}`);
  return lines.join("\n");
}

export function whatsappLink(message: string) {
  return `https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
