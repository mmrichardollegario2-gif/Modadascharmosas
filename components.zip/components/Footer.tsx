import Link from "next/link";
import { Instagram, MessageCircle } from "lucide-react";
import Logo from "./Logo";
import { storeConfig, whatsappLink } from "@/lib/store";

export default function Footer() {
  return (
    <footer className="bg-charm-ink text-white">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 grid gap-10 md:grid-cols-3">
        <div className="space-y-4">
          <Logo className="[&_span]:text-white" markClassName="" />
          <p className="text-sm text-white/60 font-sans max-w-xs">
            Peças selecionadas com elegância para a mulher que quer se sentir charmosa em qualquer ocasião.
          </p>
        </div>

        <div className="font-sans text-sm">
          <p className="eyebrow text-xs text-white/40 uppercase mb-4">Navegação</p>
          <ul className="space-y-2">
            <li><Link href="/produtos" className="text-white/80 hover:text-charm-pinkSoft">Produtos</Link></li>
            <li><Link href="/sobre" className="text-white/80 hover:text-charm-pinkSoft">Sobre</Link></li>
            <li><Link href="/contato" className="text-white/80 hover:text-charm-pinkSoft">Contato</Link></li>
          </ul>
        </div>

        <div className="font-sans text-sm">
          <p className="eyebrow text-xs text-white/40 uppercase mb-4">Fale com a gente</p>
          <div className="flex flex-col gap-3">
            <a
              href={whatsappLink("Olá! Vim do site da Moda das Charmosas e quero saber mais.")}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 text-white/80 hover:text-charm-pinkSoft"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
            <a
              href={storeConfig.instagramUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 text-white/80 hover:text-charm-pinkSoft"
            >
              <Instagram className="h-4 w-4" /> {storeConfig.instagramHandle}
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/40 font-sans">
        © {new Date().getFullYear()} Moda das Charmosas. Todos os direitos reservados.
      </div>
    </footer>
  );
}
