import Link from "next/link";
import Image from "next/image";
import { Product } from "@/lib/products";
import { formatPrice } from "@/lib/store";

export default function ProductCard({ product }: { product: Product }) {
  const soldOut = product.stock === 0;
  const [imgA, imgB] = product.images;

  return (
    <Link
      href={`/produto/${product.slug}`}
      className="group block"
    >
      <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-charm-blush">
        <Image
          src={imgA}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className={`object-cover transition-opacity duration-500 ${imgB ? "group-hover:opacity-0" : ""}`}
        />
        {imgB && (
          <Image
            src={imgB}
            alt=""
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          />
        )}

        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="rounded-full bg-charm-ink px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
              Novo
            </span>
          )}
          {product.onSale && !soldOut && (
            <span className="rounded-full bg-charm-pink px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
              Promoção
            </span>
          )}
          {soldOut && (
            <span className="rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-charm-ink">
              Esgotado
            </span>
          )}
        </div>
      </div>

      <div className="mt-3 space-y-1 font-sans">
        <p className="text-sm font-medium text-charm-ink line-clamp-1">{product.name}</p>
        <p className="text-xs text-charm-ink/40">{product.code}</p>
        <div className="flex items-baseline gap-2">
          <span className="text-sm font-semibold text-charm-pink">{formatPrice(product.price)}</span>
          {product.comparePrice && (
            <span className="text-xs text-charm-ink/40 line-through">{formatPrice(product.comparePrice)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
